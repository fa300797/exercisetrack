import React from 'react'
import ActivityRecord from './ActivityRecord'
const DashboardActivityRecord = () => {
  return (
    <>
     <ActivityRecord/>
    </>
  )
}

export default DashboardActivityRecord